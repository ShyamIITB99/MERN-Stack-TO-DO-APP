import styled from "styled-components";

export const AuthorContainer = styled.span`
  font-size: 0.6rem;

  a {
    cursor: pointer;
  }
`;
