import styled from "styled-components";

export const Container = styled.div`
  background-color: white;
  color: #2d313f;
  border-radius: 15px;
  padding: 20px 30px;
`;
